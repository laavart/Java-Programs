import java.io.*;
import javax.swing.*;
import java.lang.*;

class Employee{
    private String eID;
    private String eName;
    private double eBSalary = 0;

    Employee(){}

    Employee(String eI, String eN, double eBS){
        this.eID = eI;
        this.eName = eN;
        this.eBSalary = eBS;
    }

    String getEmployeeID(){
        return this.eID;
    }

    String getEmployeeName(){
        return this.eName;
    }

    double getEmployeeBasicSalary(){
        return this.eBSalary;
    }

    void showBasicDetails(){
        System.out.println("Employee ID is "+this.getEmployeeID()+".");
        System.out.println("Employee Name is "+this.getEmployeeName()+".");
        System.out.println("Base Salary of "+this.getEmployeeName()+" is $"+this.getEmployeeBasicSalary()+".");
        System.out.println();
    }
}

class Manager extends Employee{
    private double mSalary = 0;
    private int mBonusP = 0;

    Manager(){}

    Manager(String eI, String eN, double eBS, int mBP){
        super(eI,eN,eBS);
        this.mBonusP = mBP;
        this.mSalary = eBS;
    }

    void addBonus(){
        this.mSalary += (super.getEmployeeBasicSalary()*this.mBonusP)/100;
    }

    void deductCut(int mC){
        this.mSalary -= mC;
    }

    double getDifference(){
        return (this.mSalary-this.getEmployeeBasicSalary());
    }

    double getSalary(){
        return this.mSalary;
    }

    void showDetails(){
        System.out.println("Employee Post: MANAGER");
        System.out.println("Employee ID is "+this.getEmployeeID()+".");
        System.out.println("Employee Name is "+this.getEmployeeName()+".");
        System.out.println("Base Salary of "+this.getEmployeeName()+" is $"+this.getEmployeeBasicSalary()+".");
        System.out.println("Salary of "+this.getEmployeeName()+" is $"+this.getSalary()+".");
        if(this.getDifference()>=0)
            System.out.println("Net Increment/Decrement in salary of "+this.getEmployeeName()+" this month $"+this.getDifference()+".");
        else
            System.out.println("Net Increment/Decrement in salary of "+this.getEmployeeName()+" this month -$"+(-this.getDifference())+".");
        System.out.println();
    }
}


public class Company {
    static InputStreamReader iStream = new InputStreamReader(System.in);
    static BufferedReader bRead = new BufferedReader(iStream);

    static void sp(){
        System.out.println();
    }

    static void sp(String line){
        System.out.println(line);
    }

    static String rl() throws IOException{
        return bRead.readLine();
    }

    public static void main(String[] args) throws Exception{
        String uID,uName;
        double uBSal;
        int uBPer;

        int nManagers = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of managers in your Company"));
        sp();

        Manager[] managers = new Manager[nManagers];
        int cManagers=0;

        while(true){
            sp("PLEASE SELECT AN OPTION TO CONTINUE:");
            sp("1.Add Manager");
            sp("2.Give Bonus");
            sp("3.Deduct Cut");
            sp("4.Show Basic Details");
            sp("5.Show All Details");
            sp("6.Exit");
            sp();

            sp("ENTER THE OPTION NUMBER:");
            int op = Integer.parseInt(rl());
            sp();

            boolean cond  = false;

            switch (op){
                case 1:
                    sp("Enter Manager's ID:");
                    uID = rl();
                    sp("Enter Manager's Name:");
                    uName = rl();
                    sp("Enter Manager's Basic Salary:");
                    uBSal = Integer.parseInt(rl());
                    sp("Enter Manager's Fixed Bonus Percentage:");
                    uBPer = Integer.parseInt(rl());
                    managers[cManagers++] = new Manager(uID,uName,uBSal,uBPer);
                    sp("Manager "+uName+" Added!!!");
                    sp();
                    Thread.sleep(3000);
                    break;

                case 2:
                    sp("Enter Manager's ID:");
                    uID = rl();
                    for(int i=0; i<cManagers; i++){
                        if (uID.equals(managers[i].getEmployeeID())){
                            managers[i].addBonus();
                            cond = true;
                            sp("Bonus Added to "+managers[i].getEmployeeName()+"!!!");
                            Thread.sleep(3000);
                            sp();
                        }
                    }
                    if(cond  == false){
                        sp("No Manager with exist with ID "+uID+".");
                        Thread.sleep(3000);
                        sp();
                    }
                    break;

                case 3:
                    sp("Enter Manager's ID:");
                    uID = rl();
                    for(int i=0; i<cManagers; i++){
                        if (uID.equals(managers[i].getEmployeeID())){
                            sp("Enter Cut:");
                            int cut = Integer.parseInt(rl());
                            managers[i].deductCut(cut);
                            cond  = true;
                            sp("Cut of $"+cut+" Deducted from "+managers[i].getEmployeeName()+"!!!");
                            Thread.sleep(3000);
                            sp();
                        }
                    }
                    if(cond  == false){
                        sp("No Manager with exist with ID "+uID+".");
                        Thread.sleep(3000);
                        sp();
                    }
                    break;

                case 4:
                    sp("Enter Manager's ID:");
                    uID = rl();
                    for(int i=0; i<cManagers; i++){
                        if (uID.equals(managers[i].getEmployeeID())){
                            managers[i].showBasicDetails();
                            Thread.sleep(4000);
                            cond = true;
                            sp();
                        }
                    }
                    if(cond  == false){
                        sp("No Manager with exist with ID "+uID+".");
                        Thread.sleep(3000);
                        sp();
                    }
                    break;

                case 5:
                    sp("Enter Manager's ID:");
                    uID = rl();
                    for(int i=0; i<cManagers; i++){
                        if (uID.equals(managers[i].getEmployeeID())){
                            managers[i].showDetails();
                            Thread.sleep(5000);
                            cond = true;
                            sp();
                        }
                    }
                    if(cond  == false){
                        sp("No Manager with exist with ID "+uID+".");
                        Thread.sleep(3000);
                        sp();
                    }
                    break;

                case 6:
                    iStream.close();
                    bRead.close();
                    System.exit(0);

                default:
                    sp("!!!ENTER A VALID OPTION!!!");
                    Thread.sleep(3000);
                    sp();
            }
        }
    }
}