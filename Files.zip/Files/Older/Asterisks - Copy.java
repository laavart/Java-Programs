import java.io.*;

public class Asterisks {
    static InputStreamReader iStream = new InputStreamReader(System.in);
    static BufferedReader bRead = new BufferedReader(iStream);

    static void sp(){
        System.out.println();
    }

    static void sp(String line){
        System.out.println(line);
    }

    static String rl() throws IOException {
        return bRead.readLine();
    }

    static void box(){
        System.out.println();

        System.out.println("*********");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*********");

        System.out.println();
    }

    static void oval(){
        System.out.println();

        System.out.println("   ***   ");
        System.out.println(" *     * ");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println(" *     * ");
        System.out.println("   ***   ");

        System.out.println();
    }

    static void arrow(){
        System.out.println();

        System.out.println("  *  ");
        System.out.println(" *** ");
        System.out.println("*****");
        System.out.println("  *  ");
        System.out.println("  *  ");
        System.out.println("  *  ");
        System.out.println("  *  ");
        System.out.println("  *  ");
        System.out.println("  *  ");

        System.out.println();
    }

    static void diamond(){
        System.out.println();

        System.out.println("    *    ");
        System.out.println("   * *   ");
        System.out.println("  *   *  ");
        System.out.println(" *     * ");
        System.out.println("*       *");
        System.out.println(" *     * ");
        System.out.println("  *   *  ");
        System.out.println("   * *   ");
        System.out.println("    *    ");

        System.out.println();
    }

    public static void main(String[] args) throws Exception{
        sp("This Application Displays A Box, An Oval, An Arrow & A Diamond Using Asterisks(*)");

        while (true){
            sp("PLEASE SELECT AN OPTION TO CONTINUE:");
            sp("1.Box");
            sp("2.Oval");
            sp("3.Arrow");
            sp("4.Diamond");
            sp("5.Exit");
            sp();

            sp("ENTER THE OPTION NUMBER:");
            int op = Integer.parseInt(rl());
            sp();

            switch (op){
                case 1:
                    box();
                    Thread.sleep(3000);
                    break;
                case 2:
                    oval();
                    Thread.sleep(3000);
                    break;
                case 3:
                    arrow();
                    Thread.sleep(3000);
                    break;
                case 4:
                    diamond();
                    Thread.sleep(3000);
                    break;
                case 5:
                    System.exit(0);
                    iStream.close();
                    bRead.close();
                default:
                    sp("!!!!!!!Entered A Wrong Number Please Choose From Given Options!!!!!!!");
                    Thread.sleep(4000);
            }
        }
    }
}
