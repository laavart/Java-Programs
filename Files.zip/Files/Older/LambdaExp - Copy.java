import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

interface Meme{
    boolean lencheck(String line);
}

class LambdaExp {
    static InputStreamReader iStream = new InputStreamReader(System.in);
    static BufferedReader bRead = new BufferedReader(iStream);

    static void sp(){
        System.out.println();
    }

    static void sp(String line){
        System.out.println(line);
    }

    static String rl() throws IOException {
        return bRead.readLine();
    }

    public static void main(String[] args) throws Exception {
        sp();
        sp();
        sp("Enter thew String:");
        String line = rl();
        sp();

        /*
        Meme lenfind = new Meme() {
            public boolean lencheck(String line) {
                return line.length()>10;
            }
        };
         */

        Meme lenfind = line1 -> line1.length()>10;

        if(lenfind.lencheck(line)){
            sp("Entered String PASSED!!!");
        }
        else {
            sp("Entered String FAILED!!!");
        }

        bRead.close();
        iStream.close();
    }
}