import java.io.*;

public class Console_Input {
    public static void main(String[] args) throws Exception{
        InputStreamReader iStream = new InputStreamReader(System.in);

        System.out.println("Enter Your NAME:");

        char character = (char) iStream.read();
        int count = 0;

        while(character!='a' && count < 2){
            if(character=='s'||character=='S'){
                count++;
            }
            System.out.print(character);
            character = (char) iStream.read();
        }

        iStream.close();
    }
}