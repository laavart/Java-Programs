import java.io.*;

public class Arry2 {
    public static void main(String args[]) throws IOException{

        InputStreamReader iStream = new InputStreamReader(System.in);
        BufferedReader bRead = new BufferedReader(iStream);

        System.out.println("Enter the number of Arrays:");
        int nA = Integer.parseInt(bRead.readLine());
        System.out.println("Enter the length of the Arrays:");
        int lA = Integer.parseInt(bRead.readLine());
        int[][] aRR = new int[(nA+1)][lA];

        for(int i=0; i<nA; i++){
            System.out.println("-----------------------------------------");
            System.out.println("Enter the elements of "+(i+1)+" Arrays...");
            for(int j=0; j<lA; j++){
                System.out.println("Enter "+(j+1)+" element:");
                aRR[i][j] = Integer.parseInt(bRead.readLine());
            }
        }
        System.out.println("-----------------------------------------");
        System.out.println("Values Entered Successfully...");
        System.out.println("-----------------------------------------");

        for(int i=0; i<lA; i++){
            aRR[nA][i] = 0;
            for(int j=0; j<nA; j++){
                aRR[nA][i]+=aRR[j][i];
            }
            System.out.print(" Element "+(i+1)+" Addition: ");
            for(int j=0; j<nA; j++){
                if(j!=nA-1){
                    System.out.print(aRR[j][i]+"+");
                }
                else{
                    System.out.print(aRR[j][i] + " = ");
                }
            }
            System.out.print(aRR[nA][i]);
            System.out.println("");
        }

        iStream.close();
        bRead.close();
    }
}
