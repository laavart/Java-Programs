import java.io.*;


class Customer{
    private String cName;
    private String cAddress;

    Customer(){}

    Customer(String cN, String cA){
        this.cName = cN;
        this.cAddress = cA;
    }

    void setCustomerName(String cN){
        this.cName = cN;
    }

    void setCustomerAddress(String cA){
        this.cAddress = cA;
    }

    String getCustomerName(){
        return this.cName;
    }

    String getCustomerAddress(){
        return this.cAddress;
    }

    void showCustomerDetails(){
        System.out.println("Address of \""+this.cName+"\" is: "+this.cAddress);
    }
}


class Item{
    private int shippingWeight;
    private String description;
    private int itemPrice;

    Item(){}

    Item(int sW, String d, int iP){
        this.shippingWeight = sW;
        this.description = d;
        this.itemPrice = iP;
    }

    void setShippingWeight(int sW){
        this.shippingWeight = sW;
    }

    void setCustomerAddress(String d){
        this.description = d;
    }

    void setItemPrice(int iP){
        this.itemPrice = iP;
    }

    int getShippingWeight(){
        return this.shippingWeight;
    }

    String getDescription(){
        return this.description;
    }

    int getItemPrice(){
        return this.itemPrice;
    }

    void showItemDetails(){
        System.out.println("Shipping Weight: "+this.shippingWeight);
        System.out.println("Description: "+this.description);
        System.out.println("Price: $"+this.itemPrice);
    }

    int getPriceForQuality(int nP){
        return (this.itemPrice*nP);
    }

    int getTax(){
        return ((this.itemPrice*18)/100);
    }

    boolean inStock(Order.OrderDetails oD, int maxQuantity){
        return (oD.getOrderQuantity()>maxQuantity?false:true);
    }
}


class Order{
    private String oDate;
    private String oStatus;

    Order(){}

    Order(String oD, String oS){
        this.oDate = oD;
        this.oStatus = oS;
    }

    void setOrderDate(String oD){
        this.oDate = oD;
    }

    void  setOrderStatus(String oS){
        this.oStatus = oS;
    }

    String getOrderDate(){
        return this.oDate;
    }

    String getOrderStatus(){
        return this.oStatus;
    }

    int calcSubTotal(OrderDetails oD, Item i){
        return (i.getItemPrice()*oD.getOrderQuantity());
    }

    int calcTax(OrderDetails oD, Item i){
        return ((this.calcSubTotal(oD, i)*18)/100);
    }

    int calcTotal(OrderDetails oD, Item i){
        return (this.calcSubTotal(oD, i)*this.calcTax(oD, i));
    }

    int calcTotalWeight(OrderDetails oD, Item i){
        return (i.getShippingWeight()*oD.getOrderQuantity());
    }


    class OrderDetails{
        private int oQuantity;
        private String tStatus;

        OrderDetails(){}

        OrderDetails(int oQ, String tS){
            this.oQuantity = oQ;
            this.tStatus = tS;
        }

        void setOrderQuantity(int oQ){
            this.oQuantity = oQ;
        }

        void setTaxStatus(String tS){
            this.tStatus = tS;
        }

        int getOrderQuantity(){
            return this.oQuantity;
        }

        String getTaxStatus(){
            return this.tStatus;
        }

        int calcSubTotal(Item i){
            return (i.getItemPrice()*this.getOrderQuantity());
        }

        int calcTax(Item i){
            return ((this.calcSubTotal(i)*18)/100);
        }

        int calcWeight(Item i){
            return (i.getShippingWeight()*this.getOrderQuantity());
        }
    }
}


public class Sales{
    static InputStreamReader iStream = new InputStreamReader(System.in);
    static BufferedReader bRead = new BufferedReader(iStream);

    static void sp(){
        System.out.println();
    }

    static void sp(String line){
        System.out.println(line);
    }

    static String rl() throws IOException{
        return bRead.readLine();
    }

    public static void main(String[] args) throws Exception{
        //Main fn()
        iStream.close();
        bRead.close();
    }
}