class Second3{

public static void main(String args[]){

System.out.println("Welcome to my First Program");

String fName = args[0];
int age = Integer.parseInt(args[1]);

System.out.println("Hello "+fName+", Your age is "+age+" Yrs.");

}

}