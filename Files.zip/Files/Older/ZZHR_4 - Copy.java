import java.util.*;

public class ZZHR_4 {
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);
        String A=sc.next();
        /* Enter your code here. Print output to STDOUT. */
        int cmp = 0;
        for(int i=0; i<A.length(); i++){
            int j = A.length()-1-i;
            if( A.charAt(i) == A.charAt(j) || A.charAt(i) == (A.charAt(j))-32 || A.charAt(i) == (A.charAt(j)+32) ){
                cmp++;
            }
        }
        if (cmp == A.length()){
            System.out.println("Yes");
        }
        else {
            System.out.println("No");
        }
    }
}
