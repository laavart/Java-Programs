import java.util.*;

public class ZZHR_1 {

    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);
        String A=sc.next();
        String B=sc.next();
        /* Enter your code here. Print output to STDOUT. */
        System.out.println(A.length()+B.length());
        System.out.println(A.compareTo(B)>0?"Yes":"No");
        A = A.replace(A.charAt(0), (char) (A.charAt(0)-32));
        B = B.replace(B.charAt(0), (char) (B.charAt(0)-32));
        System.out.println(A+" "+B);

    }
}



