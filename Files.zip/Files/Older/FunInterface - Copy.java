import java.util.function.*;

public class FunInterface {
    public static void main(String[] args) throws Exception{
        Predicate<Integer> IntNum = number -> number == Math.sqrt(Math.pow(number,2));
        System.out.println(IntNum.test(-10));
    }
}
