import java.io.*;

public class Tut20201128 {
    public static void main(String args[]) throws IOException{
        InputStreamReader iStream = new InputStreamReader(System.in);
        BufferedReader bRead = new BufferedReader(iStream);

        //Assignment Operator
        System.out.println("Enter 2 Numbers: ");
        int num1 = Integer.parseInt(bRead.readLine());
        int num2 = Integer.parseInt(bRead.readLine());

        //Conditional Operator
        if (num1<num2){
            System.out.println(num2+" is Greater Number.");
        }
        else if(num1>num2){
            System.out.println(num1+" is Greater Number.");
        }
        else {
            System.out.println("The Numbers are Equal.");
        }

        //Arithmatic Operator
        System.out.println("Addition of the numbers: "+(num1+num2));
        System.out.println("Substration of "+num1+" by "+num2+": "+(num1-num2));
        System.out.println("Multiplication of the numbers: "+(num1*num2));
        System.out.println("Division of "+num1+" by "+num2+": "+(num1/num2));
        System.out.println("Remainder on Division of "+num1+" by "+num2+": "+(num1%num2));

        //Increment and Decrement Operator
        int fact1=1 , fact2=1;
        System.out.print("Factorial of "+num1+": ");
        //----Pre Increment Operator
        for(int i=1; i<=num1; i++){
            fact1*=i;
        }
        System.out.print(fact1+"\n");
        System.out.print("Factorial of "+num2+": ");
        //----Post Decrement Operator
        for(int i=num2; i>0; --i){
            fact2*=i;
        }
        System.out.print(fact2+"\n");

        //Conditional Operator
        System.out.println(num1+" is "+(num1%2==0?"EVEN":"ODD")+" number.");
        System.out.println(num2+" is "+(num2%2==0?"EVEN":"ODD")+" number.");

        iStream.close();
        bRead.close();
    }
}
