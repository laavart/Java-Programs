import java.io.*;

class Second1 {

    public static void main(String args[]) throws IOException{

        InputStreamReader iStream = new InputStreamReader(System.in);
        BufferedReader bRead = new BufferedReader(iStream);

        System.out.println("Welcome to my First Program");

        System.out.println("Please Enter Your First Name:");
        String fName = bRead.readLine();

        System.out.println("Please Enter Your Birth Year:");
        String byear = bRead.readLine();

        System.out.println("Please Enter Current Year:");
        String cyear = bRead.readLine();

        int bYear = Integer.parseInt(byear);
        int cYear = Integer.parseInt(cyear);

        int age = cYear-bYear;

        System.out.println("Hello "+fName+", Your age is "+age+" Yrs.");

        iStream.close();
        bRead.close();
}

}