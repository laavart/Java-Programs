import java.io.*;

public class Avg {

    public static void main(String args[]) throws IOException{

        InputStreamReader iStream = new InputStreamReader(System.in);
        BufferedReader bRead = new BufferedReader(iStream);

        System.out.println("To find the average, Enter the numbers First...");

        System.out.println("Enter I Number:");
        int num1 = Integer.parseInt(bRead.readLine());

        System.out.println("Enter II Number:");
        int num2 = Integer.parseInt(bRead.readLine());

        System.out.println("Enter III Number:");
        int num3 = Integer.parseInt(bRead.readLine());

        System.out.println(average(num1,num2,num3));
        iStream.close();
        bRead.close();
    }

    static int average(int num1, int num2, int num3){
        int solution = num1+num2+num3;
        return (solution/=3);
    }
}