// Laavart 19BCG10080

class TimeSpan {
    private int totalMinutes;

    public TimeSpan(int hours, int minutes) {
        this.add(hours, minutes);
    }

    public void add(int hours, int minutes) {
        totalMinutes += 60 * hours + minutes;
    }

    public String toString() {
        return (totalMinutes/60) + " : " + (totalMinutes%60);
    }
}

public class LabAssignmentV {
    public static void main(String[] args) {
        TimeSpan t1 = new TimeSpan(3, 45);
        System.out.println("TimeSpan is " + t1.toString());

        t1.add(2, 30);
        System.out.println("TimeSpan is " + t1.toString());

        t1.add(0, 51);
        System.out.println("TimeSpan is " + t1.toString());
    }
}
