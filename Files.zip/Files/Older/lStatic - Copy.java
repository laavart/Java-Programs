class Arithmatic{
    static int addNumbers(int num1, int num2){
        return (num1+num2);
    }
}

public class lStatic {
    public static void main(String[] args){
        System.out.println(Arithmatic.addNumbers(5,4));
    }
}
