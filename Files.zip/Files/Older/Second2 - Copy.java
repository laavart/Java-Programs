import java.util.Scanner;

class Second2{

public static void main(String args[]){

Scanner scan =  new Scanner(System.in);

System.out.println("Welcome to my First Program");

System.out.println("Please Enter Your First Name:");
String fName = scan.next();

System.out.println("Please Enter Your Age:");
int age = scan.nextInt();

System.out.println("Hello "+fName+", Your age is "+age+" Yrs.");

}

}