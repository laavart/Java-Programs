//Laavart 19BCG10080
import java.io.*;

class PurchaseItem{
    private String name;
    private double unitPrice;

    protected PurchaseItem(String n, double uP){
        this.setName(n);
        this.setPrice(uP);
    }

    protected PurchaseItem(){
        this.name = "no item";
        this.unitPrice = 0;
    }

    protected double getPrice(){
        return this.unitPrice;
    }

    protected String getName(){
        return this.name;
    }

    protected void setPrice(double uP){
        this.unitPrice = uP;
    }

    protected void setName(String n){
        this.name = n;
    }

    protected String getDetails(){      //****toString()****
        return (this.getName() + " @"+ this.getPrice());
    }
}

class WeighedItem extends PurchaseItem{
    private double weight;

    protected WeighedItem(String n, double uP, double w){
        super.setName(n);
        super.setPrice(uP);
        this.setWeight(w);
    }

    protected WeighedItem(){
        super.setName("no item");
        super.setPrice(0);
        this.setWeight(0);
    }

    protected void setWeight(double w){
        this.weight = w;
    }

    protected double getWeight(){
        return this.weight;
    }

    protected String getDetails(){
        return (super.getDetails()+"  "+this.getWeight()+" kg = "+(this.getWeight()*super.getPrice())+" SR");
    }
}

class CountedItem extends PurchaseItem{
    private int quantity;

    protected CountedItem(String n, double uP, int q){
        super.setName(n);
        super.setPrice(uP);
        this.setQuantity(q);
    }

    protected CountedItem(){
        super.setName("no item");
        super.setPrice(0);
        this.setQuantity(0);
    }

    protected void setQuantity(int q){
        this.quantity = q;
    }

    protected int getQuantity(){
        return this.quantity;
    }

    protected String getDetails(){
        return (super.getDetails()+"  "+this.getQuantity()+" units = "+(this.getQuantity()*super.getPrice())+" SR");
    }
}

class LabAssignmentIII {
    static InputStreamReader iStream = new InputStreamReader(System.in);
    static BufferedReader bRead = new BufferedReader(iStream);

    static void sp(){
        System.out.println();
    }

    static void sp(String line){
        System.out.println(line);
    }

    static String rl() throws IOException{
        return bRead.readLine();
    }

    public static void main(String[] args) throws Exception{
        sp();
        sp("------------------------------------------------------------------------------");
        sp("------------------------------PRODUCT MANAGEMENT------------------------------");
        sp("------------------------------------------------------------------------------");
        sp();

        sp();
        sp("Enter Details of Product...");
        sp();

        PurchaseItem pI = null;
        try {
            sp("Enter Name of Item:");
            String pName = rl();
            sp("Enter Price of Item:");
            double pPrice = Double.parseDouble(rl());

            pI = new PurchaseItem(pName,pPrice);
        }
        catch (Exception e){
            pI = new PurchaseItem();
        }
        finally {
            try{
                sp();
                sp("Your Weighted Product Details are:");
                sp(pI.getDetails());
            }
            catch(Exception e){
                sp(""+e);
            }
        }

        sp();
        sp("Enter Details of Weighted Product...");
        sp();

        WeighedItem wI = null;
        try {
            sp("Enter Name of Weighted Item:");
            String wName = rl();
            sp("Enter Price of Weighted Item:");
            double wPrice = Double.parseDouble(rl());
            sp("Enter Weight of Weighted Item:");
            double wWeight = Double.parseDouble(rl());

            wI = new WeighedItem(wName,wPrice,wWeight);
        }
        catch (Exception e){
            wI = new WeighedItem();
        }
        finally {
            try{
                sp();
                sp("Your Weighted Product Details are:");
                sp(wI.getDetails());
            }
            catch(Exception e){
                sp(""+e);
            }
        }

        sp("Enter Details of Counted Product...");
        sp();

        CountedItem cI = null;
        try{
            sp("Enter Name of Counted Item:");
            String cName = rl();
            sp("Enter Price of Counted Item:");
            double cPrice = Double.parseDouble(rl());
            sp("Enter Weight of Counted Item:");
            int cQuantity = Integer.parseInt(rl());

            cI = new CountedItem(cName,cPrice,cQuantity);
        }
        catch(Exception e){
            cI = new CountedItem();
        }
        finally {
            try{
                sp();
                sp("Your Counted Product Details are:");
                sp(cI.getDetails());
            }
            catch (Exception e){
                sp(""+e);
            }
        }

        sp();
        sp("Thank You!!!");
        sp();

        iStream.close();
        bRead.close();
    }
}