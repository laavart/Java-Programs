import java.util.Scanner;

class UnderAgeException extends Exception{
    UnderAgeException(){
        super("Age not valid");
    }
}

public class CustomException {
    static void validate(int age) throws UnderAgeException{
        if(age<18)
            throw new UnderAgeException();
        else
            System.out.println("Welcome to vote");
    }

    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter Age:");
        int age = scan.nextInt();

        try {
            validate(age);
        }
        catch(Exception m) {
            System.out.println("Exception -> "+m);
        }
    }
}
