import java.io.*;

public class AsterisksGraph {
    static InputStreamReader iStream = new InputStreamReader(System.in);
    static BufferedReader bRead = new BufferedReader(iStream);

    static  void sAst(){
        System.out.print("*");
    }

    static void sp(){
        System.out.println();
    }

    static void sp(String line){
        System.out.println(line);
    }

    static String rl() throws IOException {
        return bRead.readLine();
    }

    public static void main(String[] args) throws Exception{
        sp("Display The Bars Of Asterisks After Your Read All Five Numbers");

        while (true) {
            sp();
            sp();
            sp("PLEASE SELECT AN OPTION TO CONTINUE:");
            sp("1.Run/ReRun");
            sp("2.Exit");
            sp();

            sp("ENTER THE OPTION NUMBER:");
            int op = Integer.parseInt(rl());
            sp();

            switch (op) {
                case 1:
                    {
                        int[] aRR = new int[5];
                        int i=0;
                        while(i<5){
                            while(true){
                                sp("Enter Number"+(i+1)+" Between 1 to 30:");
                                aRR[i]= Integer.parseInt(rl());
                                if(aRR[i]>=1&&aRR[i]<=30){
                                    sp();
                                    break;
                                }
                                else{
                                    sp("Enter a *VALID* Number!!!");
                                    sp();
                                }
                            }
                            i++;
                        }

                        sp();
                        sp("GRAPH:");
                        for (int j=0; j<5; j++){
                            for(int k=0; k<aRR[j]; k++){
                                sAst();
                            }
                            sp();
                        }
                        Thread.sleep(3000);
                        break;
                    }
                case 2:
                    System.exit(0);
                    iStream.close();
                    bRead.close();
                default:
                    sp("!!!!!!!Entered A Wrong Number Please Choose From Given Options!!!!!!!");
                    Thread.sleep(4000);
            }
        }
    }
}
