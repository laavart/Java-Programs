class Hello{

public static void main(String args[]){

System.out.println("Hello World!");
Hel h1 = new Hel();
h1.printLineSt();

}

}


class Hel{

void printLineSt(){

System.out.println("Hello EveryOne!!!");

}

}