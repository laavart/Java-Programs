import java.io.*;

public class RockPaperScissors {
    static InputStreamReader iStream = new InputStreamReader(System.in);
    static BufferedReader bRead = new BufferedReader(iStream);

    static void sp(){
        System.out.println();
    }

    static void sp(String line){
        System.out.println(line);
    }

    static String rl() throws IOException {
        return bRead.readLine();
    }

    static void rockPaperScissors(String pC1, String pC2){
        if( (pC1.equalsIgnoreCase("rock")&&pC2.equalsIgnoreCase("scissors"))
        || (pC1.equalsIgnoreCase("scissors")&&pC2.equalsIgnoreCase("paper"))
        || (pC1.equalsIgnoreCase("paper")&&pC2.equalsIgnoreCase("rock")) )
        {
            sp("Player1 Wins!!!");
        }
        else if(pC1.equalsIgnoreCase(pC2)){
            sp("It's a TIE!!!");
        }
        else{
            sp("Player2 Wins!!!");
        }
    }

    public static void main(String[] args) throws Exception {
        String p1, p2;

        sp("**********ROCK-PAPER-SCISSORS**********");

        while (true) {
            sp();
            sp();
            sp("PLEASE SELECT AN OPTION TO CONTINUE:");
            sp("1.Run/ReRun");
            sp("2.Exit");
            sp();

            sp("ENTER THE OPTION NUMBER:");
            int op = Integer.parseInt(rl());
            sp();

            switch (op) {
                case 1:
                    {
                        while (true) {
                            sp("Player1's Chance:");
                            p1 = rl();
                            if (p1.equalsIgnoreCase("rock")
                                    || p1.equalsIgnoreCase("scissors")
                                    || p1.equalsIgnoreCase("paper")) {
                                sp();
                                break;
                            } else {
                                sp("Enter a *VALID* Step!!!");
                                sp();
                            }
                        }

                        while (true){
                            sp("Player2's Chance:");
                            p2 = rl();
                            if (p2.equalsIgnoreCase("rock")
                                    || p2.equalsIgnoreCase("scissors")
                                    || p2.equalsIgnoreCase("paper")) {
                                sp();
                                break;
                            } else {
                                sp("Enter a *VALID* Step!!!");
                                sp();
                            }
                        }

                        rockPaperScissors(p1, p2);
                        Thread.sleep(3000);
                        break;
                    }
                case 2:
                    System.exit(0);
                    iStream.close();
                    bRead.close();
                default:
                    sp("!!!!!!!Entered A Wrong Number Please Choose From Given Options!!!!!!!");
                    Thread.sleep(4000);
            }
        }
    }
}
