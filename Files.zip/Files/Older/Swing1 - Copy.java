import javax.swing.*;

public class Swing1 {
    public static void main(String args[]){
        int num1, num2;
        num1 = Integer.parseInt(JOptionPane.showInputDialog("Enter The First Number:"));
        System.out.println("The First value is "+num1+".");
        num2 = Integer.parseInt(JOptionPane.showInputDialog("Enter The Second Number:"));
        System.out.println("The Second value is "+num2+".");
        JOptionPane.showMessageDialog(null,"The Sum Of The Two Numbers is "+(num1+num2)+".");
        System.out.println("The Sum Of The Two Numbers is "+(num1+num2)+".");
    }
}
