import java.io.*;

public class TempAvg {
    public static void main(String args[]) throws IOException{
        InputStreamReader iStream =  new InputStreamReader(System.in);
        BufferedReader bRead =  new BufferedReader(iStream);

        System.out.println("*************************************************");
        System.out.println("***************AVERAGE TEMPERTAURE***************");
        System.out.println("*************************************************");
        System.out.println("");

        System.out.println("Enter the number of Cities:");
        int nC = Integer.parseInt(bRead.readLine());

        int[] aRR = new int[nC];
        int avgTemp=0;

        for(int i=0; i<nC; i++){
            System.out.println("Enter the Temperature of City"+(i+1)+":");
            aRR[i] = Integer.parseInt(bRead.readLine());
            avgTemp+=aRR[i];
        }

        System.out.println("The average Teamperature of the Cities is "+(avgTemp/nC)+".");
    }
}
