import java.io.*;

public class Pin {

    public static void main(String args[]) throws IOException{

        InputStreamReader iStream = new InputStreamReader(System.in);
        BufferedReader bRead = new BufferedReader(iStream);

        System.out.println("Enter the ORIGNAL Password/PIN:");
        String pin = bRead.readLine();
        System.out.println("Starting Verification...");

        int i = 1;
        while(i<=3){

            System.out.println("Enter Password/Pin "+i+":");
            if(bRead.readLine().equals(pin)){
                System.out.println("Welcome!!!");
                break;
            }
            else{
                System.out.println("Wrong Password");
            }
            i++;
        }

        iStream.close();
        bRead.close();

    }

}
