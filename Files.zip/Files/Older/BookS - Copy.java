import javax.swing.*;
import java.io.*;


class Book{
    private String bTitle;
    private String bAuthor;
    private int nPages;

    Book() {
        System.out.println("A Book Object is been Created.");
    }

    void setBookInfo(String bT, String bA, int nP){
        this.bTitle = bT;
        this.bAuthor = bA;
        this.nPages = nP;
    }
    void showBookInfo(){
        JOptionPane.showMessageDialog(null,"The Book's Title is \""+this.bTitle
                +"\" with "+this.nPages+" Pages and the Author of the Book is, "+this.bAuthor+".",this.bTitle,JOptionPane.INFORMATION_MESSAGE);
        System.out.println("Book's Title is "+this.bTitle+".");
        System.out.println("Author of the Book is "+this.bAuthor+".");
        System.out.println("With "+this.nPages+" Number of Pages.");
        System.out.println();
    }
}


public class BookS {
    public static void main(String[] args) throws IOException{
        InputStreamReader iStream = new InputStreamReader(System.in);
        BufferedReader bRead = new BufferedReader(iStream);

        System.out.println("********************************************************************");
        System.out.println("*****************************Book System****************************");
        System.out.println("********************************************************************");
        System.out.println();

        int nBooks = Integer.parseInt(JOptionPane.showInputDialog("Enter Number of Books:"));
        System.out.println("THERE ARE TOTAL "+nBooks+" BOOKS.\n");

        Book[] allBooks = new Book[nBooks];

        for (int i=0; i<nBooks; i++){
            System.out.println("ENTER THE VALUE FOR BOOK"+(i+1)+"...");

            System.out.println("Enter Title of the Book:");
            String bT = bRead.readLine();

            System.out.println("Enter Author of the Book:");
            String bA = bRead.readLine();

            System.out.println("Enter Number of Pages in the Book:");
            int nP = Integer.parseInt(bRead.readLine());

            allBooks[i] = new Book();
            allBooks[i].setBookInfo(bT,bA,nP);

            System.out.println();
        }

        for (int i=0; i<nBooks; i++){
            allBooks[i].showBookInfo();
        }

        iStream.close();
        bRead.close();
    }
}
