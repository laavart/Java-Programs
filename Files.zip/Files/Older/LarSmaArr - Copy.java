import java.io.*;

public class LarSmaArr {
    public static void main(String args[]) throws IOException{
        InputStreamReader iStream = new InputStreamReader(System.in);
        BufferedReader bRead = new BufferedReader(iStream);

        System.out.println("Enter the length of the array:");
        int lA = Integer.parseInt(bRead.readLine());
        System.out.println("-------------------------------");

        int[] aRR = new int[lA];
        System.out.println("Enter the elements of the Array");
        for(int i=0; i<lA; i++) {
            System.out.println("Enter " + (i + 1) + " element:");
            aRR[i] = Integer.parseInt(bRead.readLine());
        }
        System.out.println("-------------------------------");

        int max = aRR[0] ,min = aRR[0];
        for(int i=0; i<lA; i++){
            for(int j=0; j<lA; j++) {
                if (aRR[i] > max) max = aRR[i];
            }
        }
        for(int i=0; i<lA; i++) {
            for (int j = 0; j < lA; j++) {
                if (aRR[i] < min) min = aRR[i];
            }
        }

        System.out.println("Maximum entry is "+max+".");
        System.out.println("Minimum entry is "+min+".");

        iStream.close();
        bRead.close();
    }
}
