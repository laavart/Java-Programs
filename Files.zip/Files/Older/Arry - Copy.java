import java.util.Arrays;

public class Arry {

    public static void main(String args[]){

        int A[] = {19,20,25,36,40};
        int B[] = {19,20,25,36,40};

        System.out.println("These two arrays are " + ( Arrays.equals(A,B) ? "Equal." : "Not Equal" ));
    }
}
