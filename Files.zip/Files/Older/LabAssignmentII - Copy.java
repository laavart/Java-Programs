//Name: Laavart
//Reg.No: 19BCG10080

class Student{
    private String sName = null ;
    private String sID = null;
    private float sGPA = 0;

    protected void setName(String name){
        this.sName = name;
    }
    protected void setId(String id){
        this.sID = id;
    }
     protected void setGPA(float gpa){
        this.sGPA = gpa;
    }
    protected String getName(){
        return this.sName;
    }
    protected String getID(){
        return this.sID;
    }
    protected float getGPA(){
        return this.sGPA;
    }
    protected void viewDetails(){
        System.out.println("ID: "+this.getID());
        System.out.println("Name: "+this.getName());
        System.out.println("GPA: "+this.getGPA());
    }
}

class Undergrad extends Student{
    int sGradYear;

    protected void setGradYear(int year){
        this.sGradYear = year;
    }
    protected int getGradYear(){
        return this.sGradYear;
    }
    protected void viewDetails(){
        System.out.println("ID: "+this.getID());
        System.out.println("Name: "+this.getName());
        System.out.println("GPA: "+this.getGPA());
        System.out.println("Year of Graduation: "+this.getGradYear());
    }
}

class Graduate extends Student{
    String sThesisTitle;

    protected void setThesisTitle(String title){
        this.sThesisTitle = title;
    }
    protected String getThesisTitle(){
        return this.sThesisTitle;
    }
    protected void viewDetails(){
        System.out.println("ID: "+this.getID());
        System.out.println("Name: "+this.getName());
        System.out.println("GPA: "+this.getGPA());
        System.out.println("Title of Thesis: "+this.getThesisTitle());
    }
}

public class LabAssignmentII {
    public static void main(String[] args) throws Exception{
        //Main fn()
    }
}
