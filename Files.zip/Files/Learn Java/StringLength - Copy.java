


public class StringLength {

	public static void main(String[] args) {
		String s = "Successfully";
			
		System.out.println(s.length());
		if(s.length()>10) {
			System.out.println("Yes. The string length is > 10 ");
		}
		else {
			System.out.println("Yes. The string length is short ");
		}
		
	}

}
