
public class Array1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int array[];   
		 int count;   
		 int sizeofarray;   

		 array = new int[5];   
		  
		}
	}

