
public class Callable {

}
