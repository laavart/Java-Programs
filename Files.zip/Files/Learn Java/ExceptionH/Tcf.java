//try catch finally

public class Tcf{
public static void main(String[] args) {
    try{
               //Custom logic
    }catch(Exception e){
        // if some exception will come inside try block 
        //then only catch block will execute    
    }finally {
        //it will execute always even exception comes inside try block or not
    }
}
}

