
public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello world; I am Happy");

	}

}
