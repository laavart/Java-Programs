//Priya Singh 19BCE10359
import java.util.*;
class CountedItem extends PurchaseItem1
{
    private int quantity;
        public CountedItem() {   
        }
   
    public CountedItem(int quantity) {
                this.quantity = quantity;
            }
   
    public int getQuantity() {
                return quantity;
            }

    public void setQuantity(int quantity) {
                this.quantity = quantity;
            }

    public double getPrice()
            {
                return quantity*super.getPrice();
            }

    public String toString() {
        return super.toString()+quantity+"units "+getPrice()+"SR";
    }
   
   
}
 class PurchaseItem1
{
    private String name;
    private double unitPrice;
   
    public PurchaseItem1() {
        this.name = "No Item";
        this.unitPrice = 0;
    }
   
    public PurchaseItem1(String name, double unitPrice) {
        this.name = name;
        this.unitPrice = unitPrice;
    }
   
    public void getData() {
       
        System.out.println("Name            :- "+name);
        System.out.println("Unit Price            :- "+unitPrice);   
    }
   
    public void setData(String name, double unitprice) {
       
        this.name = name;
        this.unitPrice=unitprice;
    }
   
    public double getPrice(){
       
        return unitPrice;
    }

    public String toString() {
        return name + " @ " + unitPrice ;
    }
}


 class WeighedItem1 extends PurchaseItem1
{
    private double weight;
   
    public WeighedItem1() {
       
    }
   
    public WeighedItem1(double weight) {
        this.weight = weight;
    }
       
    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getPrice()
    {
        return weight*super.getPrice();
    }
   
    public String toString() {
        return super.toString()+" "+weight+"kg "+getPrice()+"SR";
    }
   
   
}
 class Program123 {

public static void main(String[] args) {

            Scanner scan=new Scanner(System.in);
            System.out.println("Weighted item");
            System.out.println("Enter Name, Unit Price, Weight :-");WeighedItem1 w = new WeighedItem1();
            w.setData(scan.next(), scan.nextDouble());
            w.setWeight(scan.nextDouble());
           
            System.out.println(" "+w.toString());
            System.out.println("Counted item");
            System.out.println("Please Enter Name, Unit Price, Quantity :-");
            CountedItem c = new CountedItem();
            c.setData(scan.next(), scan.nextDouble());
            c.setQuantity(scan.nextInt());
            System.out.println(" "+c.toString());
            }
}